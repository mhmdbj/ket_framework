import {Page, NavController} from 'ionic-angular';


@Page({
  templateUrl: 'build/pages/createorder/createorder.html',
})
export class CreateorderPage {
  constructor(public nav: NavController) {}
}
