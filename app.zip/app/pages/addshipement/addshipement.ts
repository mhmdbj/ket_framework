import {Page, NavController} from 'ionic-angular';

/*
  Generated class for the AddshipementPage page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Page({
  templateUrl: 'build/pages/addshipement/addshipement.html',
})
export class AddshipementPage {
  constructor(public nav: NavController) {}
}
