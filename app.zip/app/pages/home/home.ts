import {Page} from 'ionic-angular';
import {LoginPage} from '../login/login';
import {AdditemPage} from '../additem/additem';
import {AddshipementPage} from '../addshipement/addshipement';
import {CreateorderPage} from '../createorder/createorder';
import {ManagesupplierPage} from '../managesupplier/managesupplier';
import {TravelPage} from '../travel/travel';

@Page({
  templateUrl: 'build/pages/home/home.html'
})
export class HomePage {
   loginPage = LoginPage;
   additemPage =AdditemPage;
   addshipementPage = AddshipementPage;
   createorderPage = CreateorderPage;
   managesupplierPage = ManagesupplierPage;
   travelPage = TravelPage;

  constructor() {

  }
}
